# iGEM scraper script
Parses iGEM teams and biobricks.

Example usage:
```shell script
$ gradle run --args='test@test.cz tester http://localhost:3001'
```